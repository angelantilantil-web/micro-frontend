import test from 'node:test';
import assert from 'node:assert/strict';
import { buildToolDefinitions, getForwardableHeaders, loadOpenApiSpec, parseCliArgs } from '../server.js';

const sampleSpec = {
  openapi: '3.0.0',
  info: { title: 'Demo API', version: '1.0.0' },
  servers: [{ url: 'https://api.example.com' }],
  paths: {
    '/users/{id}': {
      get: {
        operationId: 'getUser',
        parameters: [
          { name: 'id', in: 'path', required: true, schema: { type: 'string' } }
        ],
        responses: { '200': { description: 'ok' } }
      }
    }
  }
};

test('buildToolDefinitions creates a tool for each operation', () => {
  const tools = buildToolDefinitions(sampleSpec);
  assert.equal(tools.length, 1);
  assert.equal(tools[0].name, 'get_users_id');
  assert.ok(tools[0].inputSchema.properties.id);
});

test('loadOpenApiSpec parses JSON from text', async () => {
  const spec = await loadOpenApiSpec(JSON.stringify(sampleSpec));
  assert.equal(spec.info.title, 'Demo API');
});

test('parseCliArgs reads headers from environment variables', () => {
  const options = parseCliArgs([], {
    OPENAPI_SPEC_URL: 'https://example.com/openapi.json',
    OPENAPI_BASE_URL: 'https://api.example.com',
    OPENAPI_HEADER_AUTHORIZATION: 'Bearer test-token',
    OPENAPI_HEADER_X_API_KEY: 'abc123'
  });

  assert.equal(options.spec, 'https://example.com/openapi.json');
  assert.equal(options.serverUrl, 'https://api.example.com');

  const authorizationHeader = Object.entries(options.headers).find(([name]) => name.toLowerCase() === 'authorization');
  const apiKeyHeader = Object.entries(options.headers).find(([name]) => name.toLowerCase() === 'x-api-key');

  assert.equal(authorizationHeader?.[1], 'Bearer test-token');
  assert.equal(apiKeyHeader?.[1], 'abc123');
});

test('parseCliArgs supports streamable-http transport options', () => {
  const options = parseCliArgs(['--transport', 'streamable-http', '--port', '3001', '--host', '0.0.0.0', '--endpoint', '/custom/mcp'], {
    OPENAPI_SPEC_URL: 'https://example.com/openapi.json'
  });

  assert.equal(options.transport, 'streamable-http');
  assert.equal(options.port, 3001);
  assert.equal(options.host, '0.0.0.0');
  assert.equal(options.endpoint, '/custom/mcp');
});

test('buildToolDefinitions removes helper-only input fields and preserves request body schema', () => {
  const specWithBody = {
    openapi: '3.0.0',
    info: { title: 'Body API', version: '1.0.0' },
    servers: [{ url: 'https://api.example.com' }],
    paths: {
      '/posts': {
        post: {
          operationId: 'createPost',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    title: { type: 'string' },
                    content: { type: 'string' }
                  },
                  required: ['title']
                }
              }
            }
          },
          responses: { '200': { description: 'created' } }
        }
      }
    }
  };

  const tools = buildToolDefinitions(specWithBody);
  assert.equal(tools.length, 1);
  const inputSchema = tools[0].inputSchema;
  assert.ok(!inputSchema.properties.headers);
  assert.ok(!inputSchema.properties.baseUrl);
  assert.ok(!inputSchema.properties.timeoutMs);
  assert.deepEqual(inputSchema.properties.body.type, 'object');
  assert.deepEqual(inputSchema.properties.body.properties.title.type, 'string');
  assert.deepEqual(inputSchema.properties.body.properties.content.type, 'string');
  assert.ok(inputSchema.required.includes('body'));
});

test('getForwardableHeaders filters out MCP transport headers', () => {
  const headers = {
    host: 'localhost',
    authorization: 'Bearer token',
    'mcp-session-id': 'abc123',
    accept: 'application/json',
    'x-custom-header': 'value'
  };

  const forwarded = getForwardableHeaders(headers);
  assert.deepEqual(forwarded, {
    authorization: 'Bearer token',
    'x-custom-header': 'value'
  });
});
