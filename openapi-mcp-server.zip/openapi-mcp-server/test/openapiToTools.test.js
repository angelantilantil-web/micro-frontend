import test from 'node:test';
import assert from 'node:assert/strict';
import { buildToolDefinitions, loadOpenApiSpec, parseCliArgs } from '../server.js';

const sampleSpec = {
  openapi: '3.0.0',
  info: { title: 'Demo API', version: '1.0.0' },
  servers: [{ url: 'https://api.example.com' }],
  paths: {
    '/users/{id}': {
      get: {
        operationId: 'getUser',
        parameters: [
          { name: 'id', in: 'path', required: true, schema: { type: 'string' } }
        ],
        responses: { '200': { description: 'ok' } }
      }
    }
  }
};

test('buildToolDefinitions creates a tool for each operation', () => {
  const tools = buildToolDefinitions(sampleSpec);
  assert.equal(tools.length, 1);
  assert.equal(tools[0].name, 'get_users_id');
  assert.ok(tools[0].inputSchema.properties.id);
});

test('loadOpenApiSpec parses JSON from text', async () => {
  const spec = await loadOpenApiSpec(JSON.stringify(sampleSpec));
  assert.equal(spec.info.title, 'Demo API');
});

test('parseCliArgs reads headers from environment variables', () => {
  const options = parseCliArgs([], {
    OPENAPI_SPEC_URL: 'https://example.com/openapi.json',
    OPENAPI_BASE_URL: 'https://api.example.com',
    OPENAPI_HEADER_AUTHORIZATION: 'Bearer test-token',
    OPENAPI_HEADER_X_API_KEY: 'abc123'
  });

  assert.equal(options.spec, 'https://example.com/openapi.json');
  assert.equal(options.serverUrl, 'https://api.example.com');

  const authorizationHeader = Object.entries(options.headers).find(([name]) => name.toLowerCase() === 'authorization');
  const apiKeyHeader = Object.entries(options.headers).find(([name]) => name.toLowerCase() === 'x-api-key');

  assert.equal(authorizationHeader?.[1], 'Bearer test-token');
  assert.equal(apiKeyHeader?.[1], 'abc123');
});

test('parseCliArgs supports streamable-http transport options', () => {
  const options = parseCliArgs(['--transport', 'streamable-http', '--port', '3001', '--host', '0.0.0.0', '--endpoint', '/custom/mcp'], {
    OPENAPI_SPEC_URL: 'https://example.com/openapi.json'
  });

  assert.equal(options.transport, 'streamable-http');
  assert.equal(options.port, 3001);
  assert.equal(options.host, '0.0.0.0');
  assert.equal(options.endpoint, '/custom/mcp');
});
