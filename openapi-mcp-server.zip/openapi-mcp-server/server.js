#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';

function normalizeText(value) {
  return String(value).replace(/[^a-zA-Z0-9]+/g, '_').replace(/^_+|_+$/g, '').toLowerCase();
}

function buildToolName(method, route) {
  const segments = route
    .split('/')
    .filter(Boolean)
    .map((segment) => {
      const match = segment.match(/\{([^}]+)\}/);
      return match ? match[1] : segment;
    });

  const cleaned = segments.length > 0 ? segments.join('_') : 'root';
  return `${normalizeText(method)}_${normalizeText(cleaned)}`;
}

function createJsonSchemaForParameter(parameter) {
  const schema = {
    type: 'string',
    description: parameter.description || `${parameter.in} parameter`
  };

  if (parameter.schema) {
    if (parameter.schema.type) schema.type = parameter.schema.type;
    if (parameter.schema.enum) schema.enum = parameter.schema.enum;
    if (parameter.schema.format) schema.format = parameter.schema.format;
    if (parameter.schema.default !== undefined) schema.default = parameter.schema.default;
    if (parameter.schema.items) schema.items = parameter.schema.items;
  }

  if (parameter.in === 'body') {
    schema.type = 'object';
  }

  return schema;
}

function buildInputSchema(spec, pathName, operation, method) {
  const parameters = [];
  const pathItem = spec.paths?.[pathName] || {};
  const pathParams = Array.isArray(pathItem.parameters) ? pathItem.parameters : [];
  const opParams = Array.isArray(operation.parameters) ? operation.parameters : [];

  const mergedParameters = [...pathParams, ...opParams];
  const schema = {
    type: 'object',
    properties: {
      headers: {
        type: 'object',
        description: 'Additional headers to forward to the target API.',
        additionalProperties: { type: 'string' }
      },
      baseUrl: {
        type: 'string',
        description: 'Optional override for the target API base URL.'
      },
      timeoutMs: {
        type: 'number',
        description: 'Optional request timeout in milliseconds.'
      }
    },
    required: []
  };

  mergedParameters.forEach((parameter) => {
    const propertyName = parameter.name;
    const parameterSchema = createJsonSchemaForParameter(parameter);
    schema.properties[propertyName] = parameterSchema;

    if (parameter.required) {
      schema.required.push(propertyName);
    }
  });

  if (operation.requestBody) {
    schema.properties.body = {
      description: 'Request body to send to this operation.',
      type: 'object'
    };
  }

  return schema;
}

function buildToolDefinitions(spec, options = {}) {
  const tools = [];
  const paths = spec.paths || {};

  Object.entries(paths).forEach(([pathName, pathItem]) => {
    const operations = ['get', 'post', 'put', 'patch', 'delete', 'options', 'head'];

    operations.forEach((method) => {
      const operation = pathItem?.[method];
      if (!operation) {
        return;
      }

      const toolName = buildToolName(method, pathName);
      const description = operation.summary || operation.description || `${method.toUpperCase()} ${pathName}`;
      tools.push({
        name: toolName,
        description,
        inputSchema: buildInputSchema(spec, pathName, operation, method),
        method: method.toUpperCase(),
        path: pathName,
        operation,
        serverUrl: options.serverUrl || spec.servers?.[0]?.url || ''
      });
    });
  });

  return tools;
}

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

function normalizeHeaderName(name) {
  return name
    .split('-')
    .map((part) => {
      if (part.length <= 3) {
        return part.toUpperCase();
      }
      return part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
    })
    .join('-');
}

function parseCliArgs(argv, env = process.env) {
  const options = {
    spec: env.OPENAPI_SPEC_URL || env.OPENAPI_URL || env.OPENAPI_SPEC_PATH || null,
    serverUrl: env.OPENAPI_SERVER_URL || env.OPENAPI_BASE_URL || null,
    headers: {}
  };

  Object.entries(env).forEach(([key, value]) => {
    if (!value) {
      return;
    }

    if (key === 'OPENAPI_HEADERS') {
      try {
        const parsedHeaders = JSON.parse(value);
        Object.entries(parsedHeaders).forEach(([headerName, headerValue]) => {
          options.headers[headerName] = String(headerValue);
        });
      } catch {
        // Ignore invalid JSON and rely on the CLI or other env values.
      }
      return;
    }

    if (key.startsWith('OPENAPI_HEADER_')) {
      const headerName = normalizeHeaderName(key.replace(/^OPENAPI_HEADER_/, '').replace(/_/g, '-'));
      options.headers[headerName] = value;
    }
  });

  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    if (argument === '--spec' || argument === '--url') {
      options.spec = argv[index + 1];
      index += 1;
    } else if (argument === '--base-url' || argument === '--server-url') {
      options.serverUrl = argv[index + 1];
      index += 1;
    } else if (argument === '--header') {
      const headerValue = argv[index + 1];
      if (!headerValue) {
        continue;
      }
      const [name, value] = headerValue.split('=');
      if (name && value) {
        options.headers[name] = value;
      }
      index += 1;
    } else if (argument === '--help' || argument === '-h') {
      options.help = true;
    }
  }

  return options;
}

function printHelp() {
  console.log(`Usage:\n  node server.js --spec <openapi-url> [--base-url <url>] [--header Name=value]\n\nExamples:\n  node server.js --spec https://example.com/openapi.json\n  node server.js --spec https://example.com/openapi.json --base-url https://api.example.com\n`);
}

async function loadOpenApiSpec(source, options = {}) {
  if (!source) {
    throw new Error('No OpenAPI URL was provided. Use --spec with an https://... URL.');
  }

  if (source.trim().startsWith('{') || source.trim().startsWith('[')) {
    return JSON.parse(source);
  }

  if (!/^https?:\/\//i.test(source)) {
    throw new Error('OpenAPI source must be an HTTP(S) URL.');
  }

  const response = await fetch(source, {
    method: 'GET',
    headers: {
      Accept: 'application/json',
      ...(options.headers || {})
    }
  });

  if (!response.ok) {
    throw new Error(`Unable to load OpenAPI document: ${response.status} ${response.statusText}`);
  }

  const text = await response.text();
  return JSON.parse(text);
}

function buildRequestUrl(baseUrl, route, args) {
  const normalizedBaseUrl = (baseUrl || '').replace(/\/$/, '');
  const normalizedRoute = route.startsWith('/') ? route : `/${route}`;
  const url = new URL(`${normalizedBaseUrl}${normalizedRoute}`);

  const queryEntries = [];
  Object.entries(args || {}).forEach(([key, value]) => {
    if (value === undefined || value === null) {
      return;
    }

    if (['headers', 'body', 'baseUrl', 'timeoutMs'].includes(key)) {
      return;
    }

    if (typeof value === 'object') {
      return;
    }

    queryEntries.push([key, String(value)]);
  });

  queryEntries.forEach(([key, value]) => {
    url.searchParams.set(key, value);
  });

  return url;
}

function interpolateRoute(route, args) {
  let resolved = route;
  Object.entries(args || {}).forEach(([key, value]) => {
    if (value === undefined || value === null) {
      return;
    }
    if (typeof value === 'object' || ['headers', 'body', 'baseUrl', 'timeoutMs'].includes(key)) {
      return;
    }
    resolved = resolved.replace(new RegExp(`\\{${key}\\}`, 'g'), encodeURIComponent(String(value)));
  });

  return resolved;
}

async function executeToolCall(tool, args, defaultHeaders = {}) {
  const method = tool.method;
  const route = interpolateRoute(tool.path, args);
  const parsedBaseUrl = args.baseUrl || tool.serverUrl || '';
  const requestUrl = buildRequestUrl(parsedBaseUrl, route, args);
  const forwardedHeaders = { ...(defaultHeaders || {}), ...(args.headers || {}) };

  const requestHeaders = { ...forwardedHeaders };

  Object.entries(args || {}).forEach(([key, value]) => {
    if (key === 'headers' || key === 'body' || key === 'baseUrl' || key === 'timeoutMs') {
      return;
    }

    if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
      return;
    }

    if (typeof value === 'undefined' || value === null) {
      return;
    }

    requestHeaders[key] = String(value);
  });

  if (args.body !== undefined) {
    if (typeof args.body === 'object' && !Buffer.isBuffer(args.body)) {
      requestHeaders['content-type'] = requestHeaders['content-type'] || 'application/json';
    }
  }

  const payload = args.body === undefined ? undefined : typeof args.body === 'string' ? args.body : JSON.stringify(args.body);

  const timeoutMs = Number(args.timeoutMs || 0);
  const controller = new AbortController();
  const timeout = timeoutMs > 0 ? setTimeout(() => controller.abort(), timeoutMs) : null;

  try {
    const response = await fetch(requestUrl, {
      method,
      headers: requestHeaders,
      body: payload,
      signal: controller.signal
    });

    const rawText = await response.text();
    let parsedBody;
    try {
      parsedBody = JSON.parse(rawText);
    } catch {
      parsedBody = rawText;
    }

    return {
      ok: response.ok,
      status: response.status,
      statusText: response.statusText,
      url: requestUrl.toString(),
      headers: Object.fromEntries(response.headers.entries()),
      body: parsedBody
    };
  } finally {
    if (timeout) {
      clearTimeout(timeout);
    }
  }
}

function createServer(spec, options = {}) {
  const tools = buildToolDefinitions(spec, options);

  const server = new Server(
    {
      name: 'openapi-to-mcp-server',
      version: '1.0.0'
    },
    {
      capabilities: {
        tools: {}
      }
    }
  );

  server.setRequestHandler(ListToolsRequestSchema, async () => ({
    tools: tools.map((tool) => ({
      name: tool.name,
      description: tool.description,
      inputSchema: tool.inputSchema
    }))
  }));

  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const tool = tools.find((candidate) => candidate.name === request.params.name);
    if (!tool) {
      throw new Error(`Tool not found: ${request.params.name}`);
    }

    const result = await executeToolCall(tool, request.params.arguments || {}, options.headers || {});
    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(result, null, 2)
        }
      ]
    };
  });

  return server;
}

async function main() {
  const options = parseCliArgs(process.argv.slice(2));
  if (options.help) {
    printHelp();
    return;
  }

  const spec = await loadOpenApiSpec(options.spec, { headers: options.headers });
  const server = createServer(spec, options);
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error(`OpenAPI MCP server is listening. Loaded ${Object.keys(spec.paths || {}).length} paths.`);
}

const isMainModule = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);

if (isMainModule) {
  main().catch((error) => {
    console.error(error instanceof Error ? error.stack || error.message : error);
    process.exit(1);
  });
}

export { buildToolDefinitions, createServer, executeToolCall, loadOpenApiSpec, parseCliArgs };
