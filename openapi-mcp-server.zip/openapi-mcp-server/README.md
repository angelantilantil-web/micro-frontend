# OpenAPI to MCP Tool Server

This Node-based MCP server converts an OpenAPI document into MCP tools. It loads the OpenAPI JSON from an HTTP(S) URL, exposes each operation as an MCP tool, and forwards headers to the downstream API when a tool is invoked.

## Features

- Loads the OpenAPI document from an HTTP(S) URL
- Converts each OpenAPI operation into an MCP tool
- Supports path, query, header, and body parameters
- Forwards configured headers from environment variables or CLI flags
- Automatically forwards custom headers supplied by the caller by default
- Supports an optional base URL override for the target service

## Transport and network details

This server can run in two modes:

- `stdio` (default): communicates over standard input/output and does not expose a port or HTTP endpoint
- `streamable-http`: starts an HTTP server on a host/port and exposes an MCP endpoint such as `/mcp`

For `streamable-http`, start it with:

```bash
npm start -- --spec https://example.com/openapi.json --transport streamable-http --host 127.0.0.1 --port 3001 --endpoint /mcp
```

You can also configure the host, port, and endpoint through environment variables:

```env
MCP_TRANSPORT=streamable-http
MCP_HOST=127.0.0.1
MCP_PORT=3001
MCP_ENDPOINT=/mcp
```

The server will then be reachable at:

```text
http://127.0.0.1:3001/mcp
```

You can also check it with:

```bash
curl http://127.0.0.1:3001/health
```

## Configuration

Create a copy of [.env.example](.env.example) as [.env](.env) and update it with your values:

```env
OPENAPI_SPEC_URL=https://petstore3.swagger.io/api/v3/openapi.json
OPENAPI_BASE_URL=https://petstore3.swagger.io/api/v3
MCP_TRANSPORT=streamable-http
MCP_HOST=127.0.0.1
MCP_PORT=3001
MCP_ENDPOINT=/mcp
OPENAPI_HEADER_Authorization=Bearer YOUR_TOKEN
OPENAPI_HEADER_X_API_KEY=YOUR_API_KEY
```

You can also pass headers directly at startup:

```bash
npm start -- --spec https://example.com/openapi.json --header Authorization=Bearer TOKEN
```

## Usage

### Start the server with environment variables

```bash
npm start
```

### Start the server with a URL directly

```bash
npm start -- --spec https://example.com/openapi.json
```

### Override the target API base URL

```bash
npm start -- --spec https://example.com/openapi.json --base-url https://api.example.com
```

## Tool invocation shape

Each generated tool accepts:

- path/query/header parameters from the OpenAPI document
- a `headers` object for additional forwarded request headers
- an optional `body` object for request bodies
- an optional `baseUrl` override
- an optional `timeoutMs` value

Any custom headers provided by the caller are forwarded automatically unless they conflict with reserved tool arguments.

## Development

```bash
npm test
```
